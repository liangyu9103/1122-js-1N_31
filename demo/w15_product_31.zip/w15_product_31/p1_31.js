import { products_31, all_products_31 } from './p1_data_31.js';

let product_31 = [];

const productContainer = document.querySelector('.products-container');

console.log('products_31', products_31);

const DisplayProducts = (products) => {};

document.addEventListener('DOMContentLoaded', () => {
  DisplayProducts(products_31);
});
